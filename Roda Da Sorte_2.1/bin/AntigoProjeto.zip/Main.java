import java.util.Scanner;

public class Main {
	// Comandos
	private static final String EXIT = "sair";
	private static final String POINTS = "pontos";
	private static final String PUZZLE = "puzzle";
	private static final String PANEL = "painel";
	private static final String ROULETTE = "roleta";
	// Outputes
	private static final String INVALID_VALUE = "Valor invalido";
	private static final String INVALID_LETTER = "Letra invalida";
	private static final String INVALID_COMMAND = "Comando invalido";
	private static final String GAME_HAS_ENDED = "O jogo terminou";
	private static final String NO_MONEY = "Parabens! Infelizmente nao ganhou dinheiro";
	private static final String NOT_ENDED = "O jogo ainda nao tinha terminado";

	// Faz a output de acordo com o estado do jogo
	private static void processExit(SystemCommands C1) {
		if (C1.gameEnded() && C1.getPoints() > 0) {
			System.out.println("Parabens! Ganhou " + C1.getPoints() + " euros");
		} else if (C1.gameEnded() && C1.getPoints() <= 0) {
			System.out.println(NO_MONEY);
		} else {
			System.out.println(NOT_ENDED);
		}
	}

	// Verifica se a input est� compreendida no abeced�rio
	private static boolean checkIfLetter(String letter) {
		boolean state = true;
		char[] testing = letter.toCharArray();
		for (int i = 0; i < letter.length(); i++) {
			if (Character.isLetter(testing[i]) == false) {
				state = false;
			}
		}
		return state;
	}

	// Verifica se � mai�scula
	private static boolean checkUppercase(String letter) {
		boolean state = false;
		char[] testing = letter.toCharArray();
		for (int i = 0; i < letter.length(); i++) {
			if (Character.isUpperCase(testing[i]) == true) {
				state = true;
			}
		}
		return state;
	}

	// Verifica a validade dos inputs//
	private static boolean validity(int value, String letter) {
		letter = letter.trim();
		if (value <= 0) {
			System.out.println(INVALID_VALUE);
			return false;
		} else if (letter.length() != 1 || checkUppercase(letter) == true || checkIfLetter(letter) == false) {
			System.out.println(INVALID_LETTER);
			return false;
		} else {
			return true;
		}
	}

	// Processa comando roleta
	private static void processroleta(SystemCommands C1, Scanner input) {
		int value = input.nextInt();
		String letter = input.nextLine();
		letter = letter.trim();
		if (!validity(value, letter)) {

		} else if (C1.gameEnded()) {
			System.out.println(GAME_HAS_ENDED);
		} else {
			char aux = letter.toCharArray()[0];
			C1.roleta(value, aux);
		}
	}

	// Processa comando puzzle
	private static void processpuzzle(SystemCommands C1, Scanner input) {
		String guess = input.nextLine();
		if (!C1.gameEnded()) {
			C1.guess(guess);
		} else {
			System.out.println(GAME_HAS_ENDED);
		}
	}

	// Main
	public static void main(String[] args) {

		// Vari�veis
		Scanner input = new Scanner(System.in);
		String option;

		// Inputs iniciais: segredo/nome do concorrente
		// pre : segredo != null, 1 < segredo < 100, 1 < nomeConcorrente < 40
		String secret = input.nextLine();
		secret.toLowerCase();
		String name = input.nextLine();
		SystemCommands C1 = new SystemCommands(secret, name);

		// Menu de op��es
		do {
			option = input.next();
			switch (option) {
			// pre : valor = int, 1 < letra < 40
			case ROULETTE:
				processroleta(C1, input);
				break;
			// pre : palpite != null, palpite.length < 100
			case PUZZLE:
				processpuzzle(C1, input);
				break;
			case PANEL:
				System.out.println(C1.panelStatus());
				break;
			case POINTS:
				System.out.println(C1.getName() + " tem " + C1.getPoints() + " pontos");
				break;
			case EXIT:
				processExit(C1);
				break;
			default:
				System.out.println(INVALID_COMMAND);
				input.nextLine();
				break;
			}
		} while (!option.equals(EXIT));

		input.close();
	}

}

//https://www.youtube.com/watch?v=gJZcdGLAgaY Obrigado