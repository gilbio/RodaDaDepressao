
public class SystemCommands {

	// Vari�veis
	int bonusPoints = 1000, negativePoints = -2000, index = 0, default_capacity = 36;
	boolean endGame;
	Panel p1;
	Contestant c1;
	char[] guessedLetters = new char[default_capacity];

	// Construtor
	public SystemCommands(String s, String n) {
		p1 = new Panel(s);
		c1 = new Contestant(n);
		endGame = false;
	}

	// Comando para tentar adivinhar o segredo por completo
	public void guess(String g) {
		g = g.trim();
		if (p1.returnSecret().equals(g)) {
			c1.updatePoints(bonusPoints);
			p1.updatePanel(p1.returnSecret());
			endGame = true;
		} else{
			c1.updatePoints(negativePoints);
		}
	}

	// Vai buscar os valores da roleta e a letra escolhida pela pessoa
	public void roleta(int points, char letter) {
		panelProcess(letter, points);
		checkEnding();
	}

	// Processa o painel, come�a por converter o painel em caracters individuais,
	// compara cada elemento � letra recebida na input. Se a letra corresponder
	// aumenta o counter por 1, se counter != 0 ent�o a pessoa acertou e vai receber
	// counter * pontos, o oposto acontece quando counter == 0
	private void panelProcess(char guess, int p) {
		int counter = 0;
		char[] secretChars = (p1.returnPanel()).toCharArray();
		for (int i = 0; i < p1.returnSecret().length(); i++) {
			char q = p1.returnSecret().charAt(i);
			if (q == guess) {
				secretChars[i] = guess;
				counter++;
			}
		}
		pointProcess(guess, counter, p);
		p1.updatePanel(String.valueOf(secretChars));
	}

	// Processa os pontos, no caso de a letra ser repetida, perde pontos.
	// Se n�o perder pontos a letra adivinhada � adicionada � lista
	private void pointProcess(char guess, int counter, int pValue) {
		if (counter == 0 && guessedBefore(guess) == false) {
			c1.updatePoints(-pValue);
			addGuess(guess);
		} else if (counter != 0 && guessedBefore(guess) == false) {
			c1.updatePoints(pValue * counter);
			addGuess(guess);
		} else if (guessedBefore(guess) == true) {
			c1.updatePoints(-pValue);
		}
	}

	// Arranja os pontos
	public int getPoints() {
		return c1.returnPoints();
	}

	// Arranja o nome
	public String getName() {
		return c1.returnName();
	}

	// Mostra o painel
	public String panelStatus() {
		return p1.returnPanel();
	}

	// Adiciona a letra as letras adivinhadas
	private void addGuess(char y) {
		guessedLetters[index] = y;
		index++;
	}
	
	// Devolve o estado do jogo
	public boolean gameEnded() {
		return endGame;
	}

	// Verifica se a letra ja foi adivinhada ou n�o
	private boolean guessedBefore(char t) {
		boolean state = false;
		int i = 0;
		while (i < guessedLetters.length) {
			if (guessedLetters[i] == t) {
				state = true;
				i = guessedLetters.length;
			} else {
				i++;
			}
		}
		return state;
	}

	// Confirma se o painel ja foi adivinhado
	private void checkEnding() {
		if (p1.returnPanel().equals(p1.returnSecret())) {
			endGame = true;
		}
	}

}