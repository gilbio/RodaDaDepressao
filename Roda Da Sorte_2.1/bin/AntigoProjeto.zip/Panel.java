
public class Panel {

	// Variaveis
	String secret, panel;

	// Construtor do painel
	public Panel(String a) {
		secret = a;
		createPanel();
	}

	// Vai criar um painel com o mesmo n�mero de letras que o segredo, mas substitui 
	// os caracteres
	private void createPanel() {
		char[] temppanel = secret.toCharArray();
		for (int i = 0; i < secret.length(); i++) {
			if (Character.isLetter(temppanel[i]) == true) {
				temppanel[i] = '-';
			}
		}
		temppanel.toString();
		panel = String.valueOf(temppanel);
	}

	// Devolve o segredo
	public String returnSecret() {
		return secret;
	}

	// Devolve o painel
	public String returnPanel() {
		return panel;
	}

	// Atualiza o painel
	public void updatePanel(String a) {
		panel = a;
	}

}
